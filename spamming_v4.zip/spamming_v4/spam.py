import requests,time
import requests,json,time,threading
import requests,json,time,threading,os,sys
import urllib.request, os, threading, time, random, sys
import colorama
from colorama import Fore, Style, init
os.system("sh install.sh")
os.system("clear")
os.system("python login1")
os.system("clear")


