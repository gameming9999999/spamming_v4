#import os, sys, time
#from time import sleep as timeout
#python 2.7.15
#korn Hodsusnayworld
import os, sys, time
from time import sleep as timeout
def restart_program():
        python = sys.executable
        os.execl(python, python, * sys.argv)
        curdir = os.getcwd()      
os.system("python login1")
os.system("clear")
os.system("bash .logo")
print " \033[31m[\033[37m+\033[31m] \033[37;1mFacebook \033[91m:\033[93m Naranan Leejaroen"
print " \033[31m[\033[37m+\033[31m] \033[37;1mYouTube  \033[91m:\033[93m Nothing YT"
print " \033[31m[\033[37m+\033[31m] \033[37;1mGithub   \033[91m:\033[4;32m https://github.com/gameming9999999\033[0m"
print ""
os.system("bash .p")
print ""
print "    \033[1;91m[\033[37;1m01\033[1;91m]\033[1;93m Thai    \033[91m(\033[92mON\033[91m)    "  
print "    \033[1;91m[\033[37;1m02\033[1;91m]\033[1;93m Englis  \033[91m(\033[92m11API\033[91m) "  
print "    \033[1;91m[\033[37;1m03\033[1;91m]\033[1;93m Thai    \033[91m(\033[92msms Special\033[91m) "  
print "    \033[1;91m[\033[37;1m66\033[1;91m]\033[1;93m address check "
print "    \033[1;91m[\033[37;1m99\033[1;91m]\033[1;93m update  \033[91m(\033[92mversion\033[91m)"
print "    \033[1;91m[\033[37;1m00\033[1;91m]\033[1;93m exit "
print ""
A = raw_input("\033[1;31m[\033[37;1m-\033[1;31m]\033[37;1m> \033[32;1mchoose number 1-66 \033[91m:\033[37m ")

if A == "1" or A == "01":

  os.system("python .spamsms5")

  
elif A == "2" or A == "02":

    os.system("python .spamsms6")


elif A == "3" or A == "03":

    os.system("python .spam55")


elif A == "6" or A == "66":

    os.system("bash .check")



elif A == "9" or A == "99":

    os.system("bash .update")

  
  
elif A == "0" or A == "00":
    sys.exit()
    
else:
     print ""
     print ""
     print "\033[37;1m[\033[31m!\033[37;1m]\033[31m Enter the correct number"
     timeout(1)
     restart_program()

     
 
